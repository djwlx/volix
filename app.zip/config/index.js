"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config = {
    port: 3000,
    token: 'volix-token',
};
exports.default = config;
