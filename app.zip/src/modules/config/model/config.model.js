"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigModel = exports.AppConfigEnum = void 0;
const sequelize_1 = __importDefault(require("../../../utils/sequelize"));
const sequelize_2 = require("sequelize");
var AppConfigEnum;
(function (AppConfigEnum) {
    AppConfigEnum["cookie_115"] = "cookie_115";
    AppConfigEnum["is_115_picture_caching"] = "is_115_picture_caching";
    AppConfigEnum["picture_115_cids"] = "picture_115_cids";
    AppConfigEnum["picture_115_folders"] = "picture_115_folders";
    AppConfigEnum["picture_115_random_weights"] = "picture_115_random_weights";
    AppConfigEnum["account_qbittorrent"] = "account_qbittorrent";
    AppConfigEnum["account_openlist"] = "account_openlist";
    AppConfigEnum["account_smtp"] = "account_smtp";
    AppConfigEnum["register_email_verify_enabled"] = "register_email_verify_enabled";
})(AppConfigEnum || (exports.AppConfigEnum = AppConfigEnum = {}));
exports.ConfigModel = sequelize_1.default.define('app_config', {
    config_name: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    config_content: {
        type: sequelize_2.DataTypes.STRING,
    },
});
