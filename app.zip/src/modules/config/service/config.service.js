"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getConfig = getConfig;
exports.setConfig = setConfig;
exports.clearConfig = clearConfig;
const sequelize_1 = require("sequelize");
const logger_1 = require("../../../utils/logger");
const config_model_1 = require("../model/config.model");
function getConfigJson(data) {
    if (!data || data.length === 0) {
        return null;
    }
    const configJson = data.reduce((acc, item) => {
        const { config_name, config_content } = item.dataValues;
        acc[config_name] = config_content;
        return acc;
    }, {});
    return configJson;
}
async function getConfig(key) {
    try {
        const params = {
            attributes: ['config_name', 'config_content'],
            where: {},
        };
        if (key) {
            params.where = {
                config_name: {
                    [sequelize_1.Op.in]: Array.isArray(key) ? key : [key],
                },
            };
        }
        const res = await config_model_1.ConfigModel.findAll(params);
        return getConfigJson(res);
    }
    catch (e) {
        logger_1.log.error(e);
        return null;
    }
}
async function setConfig(key, configContent) {
    try {
        const config = await config_model_1.ConfigModel.findOne({
            where: {
                config_name: key,
            },
        });
        if (config) {
            await config.update({
                config_content: configContent,
            });
            const result = await config.save();
            return result.dataValues;
        }
        const res = await config_model_1.ConfigModel.create({
            config_name: key,
            config_content: configContent,
        });
        return res.dataValues;
    }
    catch (e) {
        logger_1.log.error(e);
    }
}
async function clearConfig(key) {
    try {
        const res = await config_model_1.ConfigModel.destroy({
            where: {
                config_name: {
                    [sequelize_1.Op.in]: Array.isArray(key) ? key : [key],
                },
            },
        });
        return res;
    }
    catch (e) {
        logger_1.log.error(e);
    }
}
