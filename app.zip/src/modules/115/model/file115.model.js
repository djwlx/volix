"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.File115Model = void 0;
const sequelize_1 = __importDefault(require("../../../utils/sequelize"));
const sequelize_2 = require("sequelize");
exports.File115Model = sequelize_1.default.define('115_file', {
    pc: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    name: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
    },
    class: {
        type: sequelize_2.DataTypes.STRING,
    },
    cid: {
        type: sequelize_2.DataTypes.STRING,
    },
});
