"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.get115FileListData = get115FileListData;
exports.get115FileData = get115FileData;
const sdk_service_1 = require("./sdk.service");
async function get115FileListData(offset, pageSize, cid) {
    const sdk = await (0, sdk_service_1.getCloud115Sdk)();
    return sdk.getFileList(offset, pageSize, cid);
}
async function get115FileData(pc, userAgent) {
    const sdk = await (0, sdk_service_1.getCloud115Sdk)();
    return sdk.getFile(pc, userAgent);
}
