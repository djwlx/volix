"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.get115QrCodeData = get115QrCodeData;
exports.get115QrCodeStatusData = get115QrCodeStatusData;
const sdk_service_1 = require("./sdk.service");
async function get115QrCodeData() {
    const sdk = await (0, sdk_service_1.getCloud115Sdk)();
    return sdk.getQrCode();
}
async function get115QrCodeStatusData(query) {
    const sdk = await (0, sdk_service_1.getCloud115Sdk)();
    const result = await sdk.getQrStatus(query);
    return result.data;
}
