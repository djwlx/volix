"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.get115UserInfoData = get115UserInfoData;
const sdk_service_1 = require("./sdk.service");
async function get115UserInfoData() {
    const sdk = await (0, sdk_service_1.getCloud115Sdk)();
    return sdk.getUserInfo();
}
