"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.login115WithAppAndSaveCookie = login115WithAppAndSaveCookie;
exports.exit115AndClearCookie = exit115AndClearCookie;
const config_model_1 = require("../../config/model/config.model");
const config_service_1 = require("../../config/service/config.service");
const sdk_service_1 = require("./sdk.service");
async function login115WithAppAndSaveCookie(uid, app) {
    const sdk = await (0, sdk_service_1.getCloud115Sdk)();
    const result = await sdk.loginWithApp(uid, app);
    await (0, config_service_1.setConfig)(config_model_1.AppConfigEnum.cookie_115, result.cookie);
    return result.data;
}
async function exit115AndClearCookie() {
    const sdk = await (0, sdk_service_1.getCloud115Sdk)();
    sdk.clearCookie();
    await (0, config_service_1.clearConfig)(config_model_1.AppConfigEnum.cookie_115);
}
