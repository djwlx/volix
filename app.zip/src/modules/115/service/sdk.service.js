"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initCloud115Sdk = initCloud115Sdk;
exports.getCloud115Sdk = getCloud115Sdk;
const _115_1 = require("../../../sdk/115");
const config_model_1 = require("../../config/model/config.model");
const config_service_1 = require("../../config/service/config.service");
let cloud115Sdk;
async function initCloud115Sdk(params) {
    if (!cloud115Sdk) {
        cloud115Sdk = (0, _115_1.create115Sdk)();
    }
    if (params?.cookie !== undefined) {
        cloud115Sdk.setCookie(params.cookie);
        return cloud115Sdk;
    }
    const configs = await (0, config_service_1.getConfig)(config_model_1.AppConfigEnum.cookie_115);
    cloud115Sdk.setCookie(configs?.cookie_115);
    return cloud115Sdk;
}
async function getCloud115Sdk() {
    if (!cloud115Sdk) {
        return initCloud115Sdk();
    }
    return cloud115Sdk;
}
