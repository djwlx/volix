"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFile115CountByCid = exports.clearFile115ByCidList = exports.clearAllFile115 = exports.setFile115List = exports.getFile115ByPc = exports.getFile115ByCidIndex = exports.getFile115ByIndex = exports.getFile115Len = void 0;
const sequelize_1 = require("sequelize");
const file115_model_1 = require("../model/file115.model");
const getFile115Len = async () => {
    return file115_model_1.File115Model.count();
};
exports.getFile115Len = getFile115Len;
const getFile115ByIndex = async (index) => {
    const result = await file115_model_1.File115Model.findOne({
        offset: index,
    });
    return result?.dataValues;
};
exports.getFile115ByIndex = getFile115ByIndex;
const getFile115ByCidIndex = async (cid, index) => {
    const result = await file115_model_1.File115Model.findOne({
        where: {
            cid,
        },
        offset: index,
    });
    return result?.dataValues;
};
exports.getFile115ByCidIndex = getFile115ByCidIndex;
const getFile115ByPc = async (pc) => {
    const result = await file115_model_1.File115Model.findOne({
        where: {
            pc,
        },
    });
    return result?.dataValues;
};
exports.getFile115ByPc = getFile115ByPc;
const setFile115List = async (list) => {
    return file115_model_1.File115Model.bulkCreate(list, {
        ignoreDuplicates: true,
    });
};
exports.setFile115List = setFile115List;
const clearAllFile115 = async () => {
    return file115_model_1.File115Model.destroy({
        where: {},
    });
};
exports.clearAllFile115 = clearAllFile115;
const clearFile115ByCidList = async (cidList) => {
    return file115_model_1.File115Model.destroy({
        where: {
            cid: {
                [sequelize_1.Op.in]: cidList,
            },
        },
    });
};
exports.clearFile115ByCidList = clearFile115ByCidList;
const getFile115CountByCid = async () => {
    const result = (await file115_model_1.File115Model.findAll({
        attributes: ['cid', [(0, sequelize_1.fn)('COUNT', (0, sequelize_1.col)('pc')), 'count']],
        group: ['cid'],
        raw: true,
    }));
    return result.reduce((acc, item) => {
        const cid = String(item.cid || '');
        if (!cid) {
            return acc;
        }
        acc[cid] = Number(item.count || 0);
        return acc;
    }, {});
};
exports.getFile115CountByCid = getFile115CountByCid;
