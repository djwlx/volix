"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const router_1 = __importDefault(require("@koa/router"));
const http_handler_1 = require("../shared/http-handler");
const index_1 = require("./index");
const router = new router_1.default({
    prefix: '/115',
});
router
    .get('/pic', (0, http_handler_1.http)(index_1.getRandom115Pic))
    .get('/pic/info', (0, http_handler_1.http)(index_1.get115PicInfo))
    .post('/pic/like', (0, http_handler_1.http)(index_1.like115Pic))
    .put('/pic/info', (0, http_handler_1.http)(index_1.set115PicInfo))
    .post('/pic/info/retry', (0, http_handler_1.http)(index_1.retry115Pic))
    .get('/user', (0, http_handler_1.http)(index_1.get115UserInfo))
    .post('/exit', (0, http_handler_1.http)(index_1.exitCloud115))
    .get('/qrcode', (0, http_handler_1.http)(index_1.get115QrCode))
    .get('/qrcode/status', (0, http_handler_1.http)(index_1.get115QrCodeStatus))
    .post('/qrcode/login', (0, http_handler_1.http)(index_1.login115ByApp))
    .get('/files/:cid', (0, http_handler_1.http)(index_1.get115FileList))
    .get('/file/:pc', (0, http_handler_1.http)(index_1.get115File))
    .delete('/pic/info', (0, http_handler_1.http)(index_1.clear115Pic));
exports.default = router;
