"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.get115File = exports.get115FileList = exports.login115ByApp = exports.get115QrCodeStatus = exports.get115QrCode = exports.exitCloud115 = exports.get115UserInfo = exports.like115Pic = exports.retry115Pic = exports.clear115Pic = exports.set115PicInfo = exports.get115PicInfo = exports.getRandom115Pic = void 0;
const ejs_1 = __importDefault(require("ejs"));
const mime_types_1 = __importDefault(require("mime-types"));
const path_1 = require("../../../utils/path");
const request_1 = __importDefault(require("../../../utils/request"));
const response_1 = require("../../../utils/response");
const http_handler_1 = require("../../shared/http-handler");
const file_service_1 = require("../service/file.service");
const picture_service_1 = require("../service/picture.service");
const qrcode_service_1 = require("../service/qrcode.service");
const session_service_1 = require("../service/session.service");
const user_service_1 = require("../service/user.service");
const getRandom115Pic = async (ctx) => {
    const ua = ctx.request.headers['user-agent'];
    const { mode } = ctx.query || {};
    const isDirect = mode === 'direct';
    const isJson = mode === 'json';
    const { url, fileName, cid, pc } = await (0, picture_service_1.getRandom115PicMeta)(ua);
    if (isDirect) {
        const streamResult = await request_1.default.get(url, {
            responseType: 'stream',
            headers: {
                'User-Agent': ua,
            },
        });
        ctx.set('Content-Type', mime_types_1.default.lookup(fileName) || 'image/png');
        ctx.body = streamResult.data;
        return;
    }
    if (isJson) {
        return {
            url,
            fileName,
            cid,
            pc,
        };
    }
    const setuHtml = `${path_1.PATH.root}/src/views/setu.ejs`;
    const html = await ejs_1.default.renderFile(setuHtml, {
        url,
        fileName,
    });
    ctx.set('Content-Type', 'text/html');
    ctx.body = html;
};
exports.getRandom115Pic = getRandom115Pic;
const get115PicInfo = async () => {
    return (0, picture_service_1.get115PicInfoData)();
};
exports.get115PicInfo = get115PicInfo;
const set115PicInfo = async (ctx) => {
    return (0, picture_service_1.set115PicInfoData)(ctx.request.body);
};
exports.set115PicInfo = set115PicInfo;
const clear115Pic = async (ctx) => {
    const body = (ctx.request.body || {});
    const queryPaths = typeof ctx.query?.paths === 'string' ? ctx.query.paths.split(',') : [];
    return (0, picture_service_1.clear115PicData)({
        paths: body.paths?.length ? body.paths : queryPaths,
    });
};
exports.clear115Pic = clear115Pic;
const retry115Pic = async (ctx) => {
    return (0, picture_service_1.retry115PicData)(ctx.request.body);
};
exports.retry115Pic = retry115Pic;
const like115Pic = async (ctx) => {
    return (0, picture_service_1.like115PicData)(ctx.request.body);
};
exports.like115Pic = like115Pic;
const get115UserInfo = async (ctx) => {
    const result = await (0, user_service_1.get115UserInfoData)();
    if (result) {
        (0, response_1.resSuccess)(ctx, {
            data: result,
        });
        return;
    }
    (0, response_1.resSuccess)(ctx, {
        code: 1,
        message: '未登录',
    });
};
exports.get115UserInfo = get115UserInfo;
const exitCloud115 = async () => {
    await (0, session_service_1.exit115AndClearCookie)();
    return true;
};
exports.exitCloud115 = exitCloud115;
const get115QrCode = async () => {
    return (0, qrcode_service_1.get115QrCodeData)();
};
exports.get115QrCode = get115QrCode;
const get115QrCodeStatus = async (ctx) => {
    const { query } = ctx.request;
    return (0, qrcode_service_1.get115QrCodeStatusData)(query);
};
exports.get115QrCodeStatus = get115QrCodeStatus;
const login115ByApp = async (ctx) => {
    const { uid, app } = ctx.request.body;
    if (!uid || !app) {
        (0, http_handler_1.badRequest)('uid或app不能为空');
    }
    return (0, session_service_1.login115WithAppAndSaveCookie)(uid, app);
};
exports.login115ByApp = login115ByApp;
const get115FileList = async (ctx) => {
    const { offset, pageSize } = ctx.query || {};
    const { cid } = ctx.params;
    return (0, file_service_1.get115FileListData)(Number(offset), Number(pageSize), cid);
};
exports.get115FileList = get115FileList;
const get115File = async (ctx) => {
    const { pc } = ctx.params;
    const ua = ctx.request.headers['user-agent'];
    return (0, file_service_1.get115FileData)(pc, ua);
};
exports.get115File = get115File;
