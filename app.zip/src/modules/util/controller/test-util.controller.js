"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.testUtil = void 0;
const testUtil = async () => {
    return {};
};
exports.testUtil = testUtil;
