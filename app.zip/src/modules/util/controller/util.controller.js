"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPackageMetaHtml = exports.getPackageMetaJson = exports.testUtil = void 0;
const util_service_1 = require("../service/util.service");
const testUtil = async () => {
    return {};
};
exports.testUtil = testUtil;
const getPackageMetaJson = async () => {
    return (0, util_service_1.getPackageMeta)();
};
exports.getPackageMetaJson = getPackageMetaJson;
const getPackageMetaHtml = async (ctx) => {
    const pkg = await (0, util_service_1.getPackageMeta)();
    ctx.set('Content-Type', 'text/html; charset=utf-8');
    ctx.body = `<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <title>Package Info</title>
  </head>
  <body>
    <h1>Package Info</h1>
    <pre>${JSON.stringify(pkg, null, 2)}</pre>
  </body>
</html>`;
};
exports.getPackageMetaHtml = getPackageMetaHtml;
