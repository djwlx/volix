"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPackageMeta = getPackageMeta;
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const path_2 = require("../../../utils/path");
async function getPackageMeta() {
    const packageJsonPath = path_1.default.join(path_2.PATH.root, 'package.json');
    const content = await promises_1.default.readFile(packageJsonPath, 'utf-8');
    const pkg = JSON.parse(content);
    return {
        name: pkg.name || '',
        version: pkg.version || '',
    };
}
