"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.http = exports.unauthorized = exports.badRequest = exports.HttpError = void 0;
const logger_1 = require("../../utils/logger");
const response_1 = require("../../utils/response");
class HttpError extends Error {
    status;
    data;
    constructor(status, message, data) {
        super(message);
        this.name = 'HttpError';
        this.status = status;
        this.data = data;
    }
}
exports.HttpError = HttpError;
const badRequest = (message, data) => {
    throw new HttpError(400, message, data);
};
exports.badRequest = badRequest;
const unauthorized = (message, data) => {
    throw new HttpError(401, message, data);
};
exports.unauthorized = unauthorized;
const http = (handler) => {
    return async (ctx, next) => {
        try {
            const result = await handler(ctx, next);
            if (result !== undefined) {
                (0, response_1.resSuccess)(ctx, {
                    data: result,
                });
            }
        }
        catch (err) {
            if (err instanceof HttpError) {
                (0, response_1.resError)(ctx, {
                    code: err.status,
                    message: err.message,
                    data: err.data,
                });
                return;
            }
            logger_1.log.error(err);
            (0, response_1.resError)(ctx, {
                code: 500,
                message: '服务器错误',
            });
        }
    };
};
exports.http = http;
