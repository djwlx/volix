"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileModel = void 0;
const sequelize_1 = __importDefault(require("../../../utils/sequelize"));
const sequelize_2 = require("sequelize");
exports.FileModel = sequelize_1.default.define('app_file', {
    name: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
    },
    mime_type: {
        type: sequelize_2.DataTypes.STRING,
    },
    size: {
        type: sequelize_2.DataTypes.FLOAT,
    },
    path: {
        type: sequelize_2.DataTypes.STRING,
    },
    extension: {
        type: sequelize_2.DataTypes.STRING,
    },
    storage: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        defaultValue: 'local',
    },
    status: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        defaultValue: 'normal',
    },
    uuid: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
});
