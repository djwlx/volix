"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadFile = exports.uploadFile = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const uuid_1 = require("uuid");
const path_2 = require("../../../utils/path");
const http_handler_1 = require("../../shared/http-handler");
const file_service_1 = require("../service/file.service");
const moveUploadedFile = async (sourcePath, targetPath) => {
    try {
        await fs_1.default.promises.rename(sourcePath, targetPath);
    }
    catch (error) {
        const err = error;
        // Docker/container environments often store temp files on a different
        // mount point than the upload directory; rename fails with EXDEV then.
        if (err.code === 'EXDEV') {
            await fs_1.default.promises.copyFile(sourcePath, targetPath);
            await fs_1.default.promises.unlink(sourcePath);
            return;
        }
        throw error;
    }
};
const uploadFile = async (ctx) => {
    const file = ctx.request.files?.file;
    if (!file) {
        (0, http_handler_1.badRequest)('文件不存在');
    }
    const { originalFilename, size, mimetype, filepath } = file;
    const safeOriginalName = path_1.default.basename(originalFilename || 'upload.bin');
    const fileUuid = (0, uuid_1.v4)();
    const newName = `${fileUuid}.${safeOriginalName}`;
    const newPath = `${path_2.PATH.upload}/${newName}`;
    const publicPath = `/file/${encodeURIComponent(newName)}`;
    await fs_1.default.promises.mkdir(path_2.PATH.upload, { recursive: true });
    await moveUploadedFile(filepath, newPath);
    return (0, file_service_1.saveFile)({
        extension: path_1.default.extname(safeOriginalName),
        name: safeOriginalName,
        uuid: fileUuid,
        size,
        mime_type: mimetype,
        path: publicPath,
    });
};
exports.uploadFile = uploadFile;
const downloadFile = async (ctx) => {
    const { fileId } = ctx.params;
    const fileInfo = await (0, file_service_1.getFile)(fileId);
    if (!fileInfo) {
        (0, http_handler_1.badRequest)('文件不存在');
    }
    const { name, mime_type } = fileInfo;
    const realPath = `${path_2.PATH.upload}/${fileId}.${name}`;
    ctx.response.set('Content-Type', mime_type);
    ctx.response.set('Content-Disposition', `inline; filename="${encodeURIComponent(name)}"`);
    ctx.body = fs_1.default.createReadStream(realPath);
};
exports.downloadFile = downloadFile;
