"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const router_1 = __importDefault(require("@koa/router"));
const http_handler_1 = require("../shared/http-handler");
const index_1 = require("./index");
const router = new router_1.default({
    prefix: '/file',
});
router.post('/upload', (0, http_handler_1.http)(index_1.uploadFile)).get('/download/:fileId', (0, http_handler_1.http)(index_1.downloadFile));
exports.default = router;
