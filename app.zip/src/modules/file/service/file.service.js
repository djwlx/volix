"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFile = exports.saveFile = void 0;
const logger_1 = require("../../../utils/logger");
const file_model_1 = require("../model/file.model");
const saveFile = async (param) => {
    try {
        const result = await file_model_1.FileModel.create(param);
        return result.dataValues;
    }
    catch (e) {
        logger_1.log.error(e);
    }
};
exports.saveFile = saveFile;
const getFile = async (uuid) => {
    try {
        const findOne = await file_model_1.FileModel.findOne({
            where: {
                uuid,
            },
        });
        return findOne?.dataValues;
    }
    catch (e) {
        logger_1.log.error(e);
    }
};
exports.getFile = getFile;
