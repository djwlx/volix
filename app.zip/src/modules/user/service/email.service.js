"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertRegisterCodeCanSend = exports.sendRegisterCodeMail = exports.verifyRegisterCode = exports.canSendRegisterVerifyCode = exports.saveRegisterVerifyCode = exports.generateRegisterVerifyCode = void 0;
const http_handler_1 = require("../../shared/http-handler");
const REGISTER_CODE_TTL_MS = 5 * 60 * 1000;
const REGISTER_CODE_SEND_INTERVAL_MS = 60 * 1000;
const registerCodeCache = new Map();
const now = () => Date.now();
const normalizeEmail = (email) => email.trim().toLowerCase();
const getRegisterCodeCache = (email) => {
    const cache = registerCodeCache.get(normalizeEmail(email));
    if (!cache) {
        return null;
    }
    if (cache.expiresAt <= now()) {
        registerCodeCache.delete(normalizeEmail(email));
        return null;
    }
    return cache;
};
const generateRegisterVerifyCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
};
exports.generateRegisterVerifyCode = generateRegisterVerifyCode;
const saveRegisterVerifyCode = (email, code) => {
    const key = normalizeEmail(email);
    registerCodeCache.set(key, {
        code,
        expiresAt: now() + REGISTER_CODE_TTL_MS,
        sendAt: now(),
    });
};
exports.saveRegisterVerifyCode = saveRegisterVerifyCode;
const canSendRegisterVerifyCode = (email) => {
    const cache = getRegisterCodeCache(email);
    if (!cache) {
        return true;
    }
    return now() - cache.sendAt >= REGISTER_CODE_SEND_INTERVAL_MS;
};
exports.canSendRegisterVerifyCode = canSendRegisterVerifyCode;
const verifyRegisterCode = (email, code) => {
    const cache = getRegisterCodeCache(email);
    if (!cache) {
        return false;
    }
    const isValid = cache.code === code.trim();
    if (isValid) {
        registerCodeCache.delete(normalizeEmail(email));
    }
    return isValid;
};
exports.verifyRegisterCode = verifyRegisterCode;
const sendRegisterCodeMail = async (params) => {
    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransport({
        host: params.smtpHost,
        port: params.smtpPort,
        secure: params.smtpSecure,
        auth: {
            user: params.smtpUsername,
            pass: params.smtpPassword,
        },
    });
    await transporter.sendMail({
        from: params.fromEmail,
        to: params.toEmail,
        subject: 'Volix 注册验证码',
        text: `你的注册验证码是 ${params.code}，5 分钟内有效。`,
        html: `<p>你的注册验证码是 <b>${params.code}</b>，5 分钟内有效。</p>`,
    });
};
exports.sendRegisterCodeMail = sendRegisterCodeMail;
const assertRegisterCodeCanSend = (email) => {
    if (!(0, exports.canSendRegisterVerifyCode)(email)) {
        (0, http_handler_1.badRequest)('验证码发送过于频繁，请稍后再试');
    }
};
exports.assertRegisterCodeCanSend = assertRegisterCodeCanSend;
