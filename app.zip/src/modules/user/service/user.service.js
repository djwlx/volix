"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUsersByRoleKeys = exports.stringifyRoleFeatures = exports.parseRoleFeatures = exports.countUsersByRoleKey = exports.deleteRole = exports.updateRole = exports.addRole = exports.queryRoles = exports.queryRole = exports.updateUser = exports.queryUsers = exports.countUsers = exports.addUser = exports.queryUser = void 0;
const sequelize_1 = require("sequelize");
const user_model_1 = require("../model/user.model");
const role_model_1 = require("../model/role.model");
const types_1 = require("@volix/types");
const queryUser = async (param) => {
    return user_model_1.UserModel.findOne({ where: param });
};
exports.queryUser = queryUser;
const addUser = async (param) => {
    return user_model_1.UserModel.create(param);
};
exports.addUser = addUser;
const countUsers = async () => {
    return user_model_1.UserModel.count();
};
exports.countUsers = countUsers;
const queryUsers = async () => {
    return user_model_1.UserModel.findAll({
        order: [['id', 'ASC']],
    });
};
exports.queryUsers = queryUsers;
const updateUser = async (id, param) => {
    return user_model_1.UserModel.update(param, {
        where: { id },
    });
};
exports.updateUser = updateUser;
const queryRole = async (param) => {
    return role_model_1.RoleModel.findOne({ where: param });
};
exports.queryRole = queryRole;
const queryRoles = async () => {
    return role_model_1.RoleModel.findAll({
        order: [['id', 'ASC']],
    });
};
exports.queryRoles = queryRoles;
const addRole = async (param) => {
    return role_model_1.RoleModel.create(param);
};
exports.addRole = addRole;
const updateRole = async (roleKey, param) => {
    return role_model_1.RoleModel.update(param, {
        where: { role_key: roleKey },
    });
};
exports.updateRole = updateRole;
const deleteRole = async (roleKey) => {
    return role_model_1.RoleModel.destroy({
        where: { role_key: roleKey },
    });
};
exports.deleteRole = deleteRole;
const countUsersByRoleKey = async (roleKey) => {
    return user_model_1.UserModel.count({
        where: {
            role_key: roleKey,
        },
    });
};
exports.countUsersByRoleKey = countUsersByRoleKey;
const parseRoleFeatures = (raw) => {
    if (!raw) {
        return [];
    }
    try {
        const features = JSON.parse(raw);
        const validSet = new Set(Object.values(types_1.AppFeature));
        return features.filter(item => validSet.has(item));
    }
    catch {
        return [];
    }
};
exports.parseRoleFeatures = parseRoleFeatures;
const stringifyRoleFeatures = (features) => {
    const validSet = new Set(Object.values(types_1.AppFeature));
    const data = features.filter(item => validSet.has(item));
    return JSON.stringify(Array.from(new Set(data)));
};
exports.stringifyRoleFeatures = stringifyRoleFeatures;
const getUsersByRoleKeys = async (roleKeys) => {
    if (roleKeys.length === 0) {
        return [];
    }
    return user_model_1.UserModel.findAll({
        where: {
            role_key: {
                [sequelize_1.Op.in]: roleKeys,
            },
        },
    });
};
exports.getUsersByRoleKeys = getUsersByRoleKeys;
