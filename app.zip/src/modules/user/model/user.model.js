"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModel = void 0;
const types_1 = require("@volix/types");
const sequelize_1 = __importDefault(require("../../../utils/sequelize"));
const sequelize_2 = require("sequelize");
exports.UserModel = sequelize_1.default.define('app_user', {
    email: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    email_verified: {
        type: sequelize_2.DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false,
    },
    nickname: {
        type: sequelize_2.DataTypes.STRING,
    },
    avatar: {
        type: sequelize_2.DataTypes.STRING,
    },
    password: {
        type: sequelize_2.DataTypes.STRING,
    },
    role: {
        type: sequelize_2.DataTypes.ENUM(...Object.values(types_1.UserRole)),
        allowNull: false,
        defaultValue: types_1.UserRole.USER,
    },
    role_key: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        defaultValue: 'default',
    },
});
