"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RoleModel = void 0;
const sequelize_1 = __importDefault(require("../../../utils/sequelize"));
const sequelize_2 = require("sequelize");
exports.RoleModel = sequelize_1.default.define('app_role', {
    role_key: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    role_name: {
        type: sequelize_2.DataTypes.STRING,
        allowNull: false,
    },
    features: {
        type: sequelize_2.DataTypes.TEXT,
        allowNull: false,
        defaultValue: '[]',
    },
});
