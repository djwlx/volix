"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const router_1 = __importDefault(require("@koa/router"));
const http_handler_1 = require("../shared/http-handler");
const index_1 = require("./index");
const authenticate_1 = __importDefault(require("../../middleware/authenticate"));
const router = new router_1.default({
    prefix: '/user',
});
router
    .post('/login', (0, http_handler_1.http)(index_1.loginUser))
    .post('/register', (0, http_handler_1.http)(index_1.registerUser))
    .get('/register-config', (0, http_handler_1.http)(index_1.getRegisterConfig))
    .post('/register-code', (0, http_handler_1.http)(index_1.sendRegisterCode))
    .use((0, authenticate_1.default)())
    .get('/me', (0, http_handler_1.http)(index_1.getCurrentUser))
    .post('/me/email-verify-code', (0, http_handler_1.http)(index_1.sendCurrentUserEmailVerifyCode))
    .post('/me/email-verify', (0, http_handler_1.http)(index_1.verifyCurrentUserEmail))
    .get('/account-configs', (0, http_handler_1.http)(index_1.getAccountConfigs))
    .put('/account-configs', (0, http_handler_1.http)(index_1.updateAccountConfig))
    .get('/system-config', (0, http_handler_1.http)(index_1.getSystemConfig))
    .put('/system-config', (0, http_handler_1.http)(index_1.updateSystemConfig))
    .put('/profile', (0, http_handler_1.http)(index_1.updateCurrentUserProfile))
    .get('/list', (0, http_handler_1.http)(index_1.getUserList))
    .put('/role', (0, http_handler_1.http)(index_1.setUserRole))
    .post('/admin-create', (0, http_handler_1.http)(index_1.adminCreateUser))
    .get('/roles', (0, http_handler_1.http)(index_1.getRoleList))
    .post('/roles', (0, http_handler_1.http)(index_1.createRole))
    .put('/roles/:roleKey', (0, http_handler_1.http)(index_1.updateRoleInfo))
    .delete('/roles/:roleKey', (0, http_handler_1.http)(index_1.removeRole))
    .put('/assign-role', (0, http_handler_1.http)(index_1.assignUserRole))
    .get('/:id', (0, http_handler_1.http)(index_1.getUserDetail))
    .put('/:id', (0, http_handler_1.http)(index_1.adminUpdateUser));
exports.default = router;
