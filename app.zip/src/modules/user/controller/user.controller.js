"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminUpdateUser = exports.adminCreateUser = exports.getUserDetail = exports.assignUserRole = exports.removeRole = exports.updateRoleInfo = exports.createRole = exports.getRoleList = exports.updateCurrentUserProfile = exports.setUserRole = exports.getUserList = exports.updateSystemConfig = exports.getSystemConfig = exports.updateAccountConfig = exports.getAccountConfigs = exports.getCurrentUser = exports.verifyCurrentUserEmail = exports.sendCurrentUserEmailVerifyCode = exports.sendRegisterCode = exports.getRegisterConfig = exports.registerUser = exports.loginUser = void 0;
const types_1 = require("@volix/types");
const types_2 = require("@volix/types");
const jwt_1 = __importDefault(require("../../../utils/jwt"));
const http_handler_1 = require("../../shared/http-handler");
const config_1 = require("../../config");
const user_service_1 = require("../service/user.service");
const email_service_1 = require("../service/email.service");
const EMAIL_REGEXP = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const AVATAR_URL_REGEXP = /^(https?:\/\/|\/file\/)/;
const DEFAULT_ROLE_KEY = 'default';
const ROLE_KEY_PREFIX = 'role';
const DEFAULT_USER_FEATURES = [types_2.AppFeature.RANDOM_PIC];
const ACCOUNT_CONFIG_KEY_MAP = {
    [types_1.AccountConfigPlatform.QBITTORRENT]: config_1.AppConfigEnum.account_qbittorrent,
    [types_1.AccountConfigPlatform.OPENLIST]: config_1.AppConfigEnum.account_openlist,
    [types_1.AccountConfigPlatform.SMTP]: config_1.AppConfigEnum.account_smtp,
};
const REGISTER_EMAIL_VERIFY_CONFIG_KEY = config_1.AppConfigEnum.register_email_verify_enabled;
const ensureDefaultRole = async () => {
    const role = await (0, user_service_1.queryRole)({
        role_key: DEFAULT_ROLE_KEY,
    });
    if (role) {
        return role;
    }
    return (0, user_service_1.addRole)({
        role_key: DEFAULT_ROLE_KEY,
        role_name: '默认角色',
        features: (0, user_service_1.stringifyRoleFeatures)(DEFAULT_USER_FEATURES),
    });
};
const getFeaturePermissionsByRoleKey = async (roleKey) => {
    if (!roleKey) {
        return [];
    }
    const role = await (0, user_service_1.queryRole)({
        role_key: roleKey,
    });
    return (0, user_service_1.parseRoleFeatures)(role?.dataValues.features);
};
const getFeaturePermissions = async (systemRole, roleKey) => {
    if (systemRole === types_1.UserRole.ADMIN) {
        return Object.values(types_2.AppFeature);
    }
    return getFeaturePermissionsByRoleKey(roleKey);
};
const normalizeRoleFeatures = (features) => {
    if (!Array.isArray(features)) {
        (0, http_handler_1.badRequest)('features 必须是数组');
    }
    const values = features;
    const validSet = new Set(Object.values(types_2.AppFeature));
    const invalid = values.find(item => !validSet.has(item));
    if (invalid) {
        (0, http_handler_1.badRequest)(`非法功能权限: ${invalid}`);
    }
    return Array.from(new Set(values));
};
const buildAutoRoleKey = () => {
    return `${ROLE_KEY_PREFIX}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
};
const normalizeServiceAccountConfig = (config) => {
    if (!config || typeof config !== 'object') {
        (0, http_handler_1.badRequest)('配置格式错误');
    }
    const raw = config;
    const baseUrl = typeof raw.baseUrl === 'string' ? raw.baseUrl.trim() : '';
    const username = typeof raw.username === 'string' ? raw.username.trim() : '';
    const password = typeof raw.password === 'string' ? raw.password.trim() : '';
    if (!baseUrl || !/^https?:\/\//.test(baseUrl)) {
        (0, http_handler_1.badRequest)('baseUrl 必须是 http/https 地址');
    }
    if (!username) {
        (0, http_handler_1.badRequest)('username 不能为空');
    }
    if (!password) {
        (0, http_handler_1.badRequest)('password 不能为空');
    }
    return {
        baseUrl,
        username,
        password,
    };
};
const normalizeSmtpAccountConfig = (config) => {
    if (!config || typeof config !== 'object') {
        (0, http_handler_1.badRequest)('SMTP 配置格式错误');
    }
    const raw = config;
    const host = typeof raw.host === 'string' ? raw.host.trim() : '';
    const port = typeof raw.port === 'number' ? raw.port : Number(raw.port);
    const secure = Boolean(raw.secure);
    const username = typeof raw.username === 'string' ? raw.username.trim() : '';
    const password = typeof raw.password === 'string' ? raw.password.trim() : '';
    const fromEmail = typeof raw.fromEmail === 'string' ? raw.fromEmail.trim() : '';
    if (!host) {
        (0, http_handler_1.badRequest)('SMTP host 不能为空');
    }
    if (!Number.isFinite(port) || port <= 0 || port > 65535) {
        (0, http_handler_1.badRequest)('SMTP port 非法');
    }
    if (!username) {
        (0, http_handler_1.badRequest)('SMTP username 不能为空');
    }
    if (!password) {
        (0, http_handler_1.badRequest)('SMTP password 不能为空');
    }
    if (!EMAIL_REGEXP.test(fromEmail)) {
        (0, http_handler_1.badRequest)('SMTP 发件邮箱格式错误');
    }
    return {
        host,
        port,
        secure,
        username,
        password,
        fromEmail,
    };
};
const parseServiceAccountConfig = (raw) => {
    if (!raw) {
        return null;
    }
    try {
        return normalizeServiceAccountConfig(JSON.parse(raw));
    }
    catch {
        return null;
    }
};
const parseSmtpAccountConfig = (raw) => {
    if (!raw) {
        return null;
    }
    try {
        return normalizeSmtpAccountConfig(JSON.parse(raw));
    }
    catch {
        return null;
    }
};
const parseBooleanConfig = (raw) => raw === 'true';
const getSystemConfigData = async () => {
    const config = await (0, config_1.getConfig)(REGISTER_EMAIL_VERIFY_CONFIG_KEY);
    return {
        registerEmailVerifyEnabled: parseBooleanConfig(config?.[REGISTER_EMAIL_VERIFY_CONFIG_KEY]),
    };
};
const toUserResponse = async (data) => {
    const role = (data.role || types_1.UserRole.USER);
    const roleKey = data.role_key || DEFAULT_ROLE_KEY;
    return {
        id: data.id,
        email: data.email,
        emailVerified: Boolean(data.email_verified),
        nickname: data.nickname,
        avatar: data.avatar,
        role,
        roleKey,
        featurePermissions: await getFeaturePermissions(role, roleKey),
    };
};
const loginUser = async (ctx) => {
    const param = ctx.request.body;
    const { email, password } = param;
    if (!email || !password) {
        (0, http_handler_1.badRequest)('邮箱或密码不能为空');
    }
    if (!EMAIL_REGEXP.test(email)) {
        (0, http_handler_1.badRequest)('邮箱格式错误');
    }
    const findOne = await (0, user_service_1.queryUser)({
        email,
        password,
    });
    if (!findOne) {
        (0, http_handler_1.badRequest)('邮箱或密码错误');
    }
    const userId = findOne?.dataValues?.id;
    if (userId === undefined || userId === null) {
        (0, http_handler_1.badRequest)('用户信息异常');
    }
    return {
        token: jwt_1.default.setToken({ id: userId }),
    };
};
exports.loginUser = loginUser;
const registerUser = async (ctx) => {
    const param = ctx.request.body;
    const email = param.email?.trim();
    const password = param.password?.trim();
    if (!email || !password) {
        (0, http_handler_1.badRequest)('邮箱或密码不能为空');
    }
    if (!EMAIL_REGEXP.test(email)) {
        (0, http_handler_1.badRequest)('邮箱格式错误');
    }
    const findOne = await (0, user_service_1.queryUser)({
        email,
    });
    if (findOne) {
        (0, http_handler_1.badRequest)('用户已存在');
    }
    const systemConfig = await getSystemConfigData();
    const smtpConfigData = await (0, config_1.getConfig)(config_1.AppConfigEnum.account_smtp);
    const smtpConfig = parseSmtpAccountConfig(smtpConfigData?.[config_1.AppConfigEnum.account_smtp]);
    const shouldVerifyEmail = systemConfig.registerEmailVerifyEnabled && Boolean(smtpConfig);
    if (shouldVerifyEmail) {
        const verifyCode = (param.verifyCode || '').trim();
        if (!verifyCode) {
            (0, http_handler_1.badRequest)('请输入邮箱验证码');
        }
        const isValid = (0, email_service_1.verifyRegisterCode)(email, verifyCode);
        if (!isValid) {
            (0, http_handler_1.badRequest)('验证码错误或已过期');
        }
    }
    const userCount = await (0, user_service_1.countUsers)();
    const role = userCount === 0 ? types_1.UserRole.ADMIN : types_1.UserRole.USER;
    const user = await (0, user_service_1.addUser)({
        email,
        email_verified: shouldVerifyEmail,
        password,
        role,
        role_key: DEFAULT_ROLE_KEY,
    });
    await ensureDefaultRole();
    const featurePermissions = await getFeaturePermissions((user.dataValues.role || role), user.dataValues.role_key);
    return {
        id: user.dataValues.id,
        email: user.dataValues.email,
        emailVerified: Boolean(user.dataValues.email_verified),
        nickname: user.dataValues.nickname,
        avatar: user.dataValues.avatar,
        role: (user.dataValues.role || role),
        roleKey: user.dataValues.role_key,
        featurePermissions,
    };
};
exports.registerUser = registerUser;
const getRegisterConfig = async () => {
    const [systemConfig, smtpConfigData] = await Promise.all([
        getSystemConfigData(),
        (0, config_1.getConfig)(config_1.AppConfigEnum.account_smtp),
    ]);
    const smtpConfig = parseSmtpAccountConfig(smtpConfigData?.[config_1.AppConfigEnum.account_smtp]);
    return {
        emailVerificationRequired: systemConfig.registerEmailVerifyEnabled && Boolean(smtpConfig),
    };
};
exports.getRegisterConfig = getRegisterConfig;
const sendRegisterCode = async (ctx) => {
    const param = (ctx.request.body || {});
    const email = param.email?.trim();
    if (!email || !EMAIL_REGEXP.test(email)) {
        (0, http_handler_1.badRequest)('邮箱格式错误');
    }
    const [systemConfig, smtpConfigData] = await Promise.all([
        getSystemConfigData(),
        (0, config_1.getConfig)(config_1.AppConfigEnum.account_smtp),
    ]);
    const smtpConfig = parseSmtpAccountConfig(smtpConfigData?.[config_1.AppConfigEnum.account_smtp]);
    if (!systemConfig.registerEmailVerifyEnabled) {
        (0, http_handler_1.badRequest)('当前未开启注册邮箱验证');
    }
    if (!smtpConfig) {
        (0, http_handler_1.badRequest)('请先在系统中配置 SMTP');
    }
    const smtp = smtpConfig;
    const exists = await (0, user_service_1.queryUser)({ email });
    if (exists) {
        (0, http_handler_1.badRequest)('用户已存在');
    }
    (0, email_service_1.assertRegisterCodeCanSend)(email);
    const code = (0, email_service_1.generateRegisterVerifyCode)();
    await (0, email_service_1.sendRegisterCodeMail)({
        smtpHost: smtp.host,
        smtpPort: smtp.port,
        smtpSecure: smtp.secure,
        smtpUsername: smtp.username,
        smtpPassword: smtp.password,
        fromEmail: smtp.fromEmail,
        toEmail: email,
        code,
    });
    (0, email_service_1.saveRegisterVerifyCode)(email, code);
    return {
        success: true,
    };
};
exports.sendRegisterCode = sendRegisterCode;
const sendCurrentUserEmailVerifyCode = async (ctx) => {
    const userId = ctx.state.userInfo?.id;
    if (!userId) {
        (0, http_handler_1.unauthorized)('未登录');
        return;
    }
    const userRecord = await (0, user_service_1.queryUser)({ id: userId });
    if (!userRecord) {
        (0, http_handler_1.unauthorized)('用户不存在');
        return;
    }
    const user = userRecord.dataValues;
    if (user.email_verified) {
        (0, http_handler_1.badRequest)('当前邮箱已完成验证');
    }
    const smtpConfigData = await (0, config_1.getConfig)(config_1.AppConfigEnum.account_smtp);
    const smtpConfig = parseSmtpAccountConfig(smtpConfigData?.[config_1.AppConfigEnum.account_smtp]);
    if (!smtpConfig) {
        (0, http_handler_1.badRequest)('请先在系统中配置 SMTP');
    }
    const email = user.email;
    (0, email_service_1.assertRegisterCodeCanSend)(email);
    const code = (0, email_service_1.generateRegisterVerifyCode)();
    const smtp = smtpConfig;
    await (0, email_service_1.sendRegisterCodeMail)({
        smtpHost: smtp.host,
        smtpPort: smtp.port,
        smtpSecure: smtp.secure,
        smtpUsername: smtp.username,
        smtpPassword: smtp.password,
        fromEmail: smtp.fromEmail,
        toEmail: email,
        code,
    });
    (0, email_service_1.saveRegisterVerifyCode)(email, code);
    const result = {
        success: true,
    };
    return result;
};
exports.sendCurrentUserEmailVerifyCode = sendCurrentUserEmailVerifyCode;
const verifyCurrentUserEmail = async (ctx) => {
    const userId = ctx.state.userInfo?.id;
    if (!userId) {
        (0, http_handler_1.unauthorized)('未登录');
        return;
    }
    const userRecord = await (0, user_service_1.queryUser)({ id: userId });
    if (!userRecord) {
        (0, http_handler_1.unauthorized)('用户不存在');
        return;
    }
    const user = userRecord.dataValues;
    if (user.email_verified) {
        (0, http_handler_1.badRequest)('当前邮箱已完成验证');
    }
    const param = (ctx.request.body || {});
    const verifyCode = (param.verifyCode || '').trim();
    if (!verifyCode) {
        (0, http_handler_1.badRequest)('请输入邮箱验证码');
    }
    const isValid = (0, email_service_1.verifyRegisterCode)(user.email, verifyCode);
    if (!isValid) {
        (0, http_handler_1.badRequest)('验证码错误或已过期');
    }
    await (0, user_service_1.updateUser)(userId, {
        email_verified: true,
    });
    const updatedRecord = await (0, user_service_1.queryUser)({ id: userId });
    if (!updatedRecord) {
        (0, http_handler_1.badRequest)('用户不存在');
        return;
    }
    return toUserResponse(updatedRecord.dataValues);
};
exports.verifyCurrentUserEmail = verifyCurrentUserEmail;
const getCurrentUser = async (ctx) => {
    const userId = ctx.state.userInfo?.id;
    if (!userId) {
        (0, http_handler_1.unauthorized)('未登录');
    }
    const user = await (0, user_service_1.queryUser)({ id: userId });
    if (!user) {
        (0, http_handler_1.unauthorized)('用户不存在');
        return;
    }
    await ensureDefaultRole();
    const featurePermissions = await getFeaturePermissions((user.dataValues.role || types_1.UserRole.USER), user.dataValues.role_key);
    return {
        id: user.dataValues.id,
        email: user.dataValues.email,
        emailVerified: Boolean(user.dataValues.email_verified),
        nickname: user.dataValues.nickname,
        avatar: user.dataValues.avatar,
        role: (user.dataValues.role || types_1.UserRole.USER),
        roleKey: user.dataValues.role_key,
        featurePermissions,
    };
};
exports.getCurrentUser = getCurrentUser;
const getAccountConfigs = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可访问');
    }
    const configData = await (0, config_1.getConfig)(Object.values(ACCOUNT_CONFIG_KEY_MAP));
    const result = {};
    if (configData?.[config_1.AppConfigEnum.account_qbittorrent]) {
        result[types_1.AccountConfigPlatform.QBITTORRENT] =
            parseServiceAccountConfig(configData[config_1.AppConfigEnum.account_qbittorrent]) || undefined;
    }
    if (configData?.[config_1.AppConfigEnum.account_openlist]) {
        result[types_1.AccountConfigPlatform.OPENLIST] =
            parseServiceAccountConfig(configData[config_1.AppConfigEnum.account_openlist]) || undefined;
    }
    if (configData?.[config_1.AppConfigEnum.account_smtp]) {
        result[types_1.AccountConfigPlatform.SMTP] = parseSmtpAccountConfig(configData[config_1.AppConfigEnum.account_smtp]) || undefined;
    }
    return result;
};
exports.getAccountConfigs = getAccountConfigs;
const updateAccountConfig = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const param = (ctx.request.body || {});
    const { platform } = param;
    if (!platform || !ACCOUNT_CONFIG_KEY_MAP[platform]) {
        (0, http_handler_1.badRequest)('platform 参数错误');
    }
    const config = platform === types_1.AccountConfigPlatform.SMTP
        ? normalizeSmtpAccountConfig(param.config)
        : normalizeServiceAccountConfig(param.config);
    const configKey = ACCOUNT_CONFIG_KEY_MAP[platform];
    await (0, config_1.setConfig)(configKey, JSON.stringify(config));
    return {
        platform,
        config,
    };
};
exports.updateAccountConfig = updateAccountConfig;
const getSystemConfig = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可访问');
    }
    return getSystemConfigData();
};
exports.getSystemConfig = getSystemConfig;
const updateSystemConfig = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const param = (ctx.request.body || {});
    if (typeof param.registerEmailVerifyEnabled !== 'boolean') {
        (0, http_handler_1.badRequest)('registerEmailVerifyEnabled 参数错误');
    }
    await (0, config_1.setConfig)(REGISTER_EMAIL_VERIFY_CONFIG_KEY, String(param.registerEmailVerifyEnabled));
    return {
        registerEmailVerifyEnabled: param.registerEmailVerifyEnabled,
    };
};
exports.updateSystemConfig = updateSystemConfig;
const getUserList = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可访问');
    }
    await ensureDefaultRole();
    const allRoles = await (0, user_service_1.queryRoles)();
    const featureMap = new Map(allRoles.map(item => [item.dataValues.role_key, (0, user_service_1.parseRoleFeatures)(item.dataValues.features)]));
    const list = await (0, user_service_1.queryUsers)();
    return list.map(item => ({
        id: item.dataValues.id,
        email: item.dataValues.email,
        emailVerified: Boolean(item.dataValues.email_verified),
        nickname: item.dataValues.nickname,
        avatar: item.dataValues.avatar,
        role: (item.dataValues.role || types_1.UserRole.USER),
        roleKey: item.dataValues.role_key,
        featurePermissions: item.dataValues.role === types_1.UserRole.ADMIN
            ? Object.values(types_2.AppFeature)
            : featureMap.get(item.dataValues.role_key || DEFAULT_ROLE_KEY) || [],
    }));
};
exports.getUserList = getUserList;
const setUserRole = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const param = ctx.request.body;
    const { userId, role } = param;
    if (!userId || !role || !Object.values(types_1.UserRole).includes(role)) {
        (0, http_handler_1.badRequest)('参数错误');
    }
    const targetUser = await (0, user_service_1.queryUser)({ id: userId });
    if (!targetUser) {
        (0, http_handler_1.badRequest)('目标用户不存在');
        return;
    }
    if (String(ctx.state.userInfo?.id) === String(userId) && role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.badRequest)('不能取消自己的管理员权限');
    }
    await (0, user_service_1.updateUser)(userId, { role });
    return {
        id: targetUser.dataValues.id,
        email: targetUser.dataValues.email,
        emailVerified: Boolean(targetUser.dataValues.email_verified),
        nickname: targetUser.dataValues.nickname,
        avatar: targetUser.dataValues.avatar,
        role,
        roleKey: targetUser.dataValues.role_key,
        featurePermissions: await getFeaturePermissions(role, targetUser.dataValues.role_key),
    };
};
exports.setUserRole = setUserRole;
const updateCurrentUserProfile = async (ctx) => {
    const userId = ctx.state.userInfo?.id;
    if (!userId) {
        (0, http_handler_1.unauthorized)('未登录');
    }
    const param = (ctx.request.body || {});
    const nextProfile = {};
    if (typeof param.nickname === 'string') {
        const nickname = param.nickname.trim();
        if (nickname.length > 32) {
            (0, http_handler_1.badRequest)('昵称长度不能超过 32');
        }
        nextProfile.nickname = nickname;
    }
    if (typeof param.avatar === 'string') {
        const avatar = param.avatar.trim();
        if (avatar && !AVATAR_URL_REGEXP.test(avatar)) {
            (0, http_handler_1.badRequest)('头像地址必须是 http/https 链接或 /file/ 开头的上传地址');
        }
        nextProfile.avatar = avatar;
    }
    if (Object.keys(nextProfile).length === 0) {
        (0, http_handler_1.badRequest)('未提供可更新的字段');
    }
    await (0, user_service_1.updateUser)(userId, nextProfile);
    const updated = await (0, user_service_1.queryUser)({ id: userId });
    if (!updated) {
        (0, http_handler_1.badRequest)('用户不存在');
        return;
    }
    return {
        id: updated.dataValues.id,
        email: updated.dataValues.email,
        emailVerified: Boolean(updated.dataValues.email_verified),
        nickname: updated.dataValues.nickname,
        avatar: updated.dataValues.avatar,
        role: (updated.dataValues.role || types_1.UserRole.USER),
        roleKey: updated.dataValues.role_key,
        featurePermissions: await getFeaturePermissions((updated.dataValues.role || types_1.UserRole.USER), updated.dataValues.role_key),
    };
};
exports.updateCurrentUserProfile = updateCurrentUserProfile;
const getRoleList = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可访问');
    }
    await ensureDefaultRole();
    const roles = await (0, user_service_1.queryRoles)();
    return roles.map(item => ({
        roleKey: item.dataValues.role_key,
        roleName: item.dataValues.role_name,
        features: (0, user_service_1.parseRoleFeatures)(item.dataValues.features),
    }));
};
exports.getRoleList = getRoleList;
const createRole = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const param = (ctx.request.body || {});
    const roleKeyInput = param.roleKey?.trim();
    const roleName = param.roleName?.trim();
    const features = normalizeRoleFeatures(param.features);
    if (!roleName) {
        (0, http_handler_1.badRequest)('角色名称不能为空');
    }
    if (roleKeyInput && !/^[a-zA-Z][a-zA-Z0-9_-]{1,31}$/.test(roleKeyInput)) {
        (0, http_handler_1.badRequest)('角色标识格式错误，需以字母开头，长度 2-32');
    }
    if (roleKeyInput === DEFAULT_ROLE_KEY) {
        (0, http_handler_1.badRequest)('default 角色不可手动创建');
    }
    let roleKey = roleKeyInput || '';
    if (!roleKey) {
        // 自动生成 roleKey，避免让用户手动输入系统标识
        do {
            roleKey = buildAutoRoleKey();
        } while (await (0, user_service_1.queryRole)({ role_key: roleKey }));
    }
    else {
        const exists = await (0, user_service_1.queryRole)({ role_key: roleKey });
        if (exists) {
            (0, http_handler_1.badRequest)('角色标识已存在');
        }
    }
    const role = await (0, user_service_1.addRole)({
        role_key: roleKey,
        role_name: roleName,
        features: (0, user_service_1.stringifyRoleFeatures)(features),
    });
    return {
        roleKey: role.dataValues.role_key,
        roleName: role.dataValues.role_name,
        features,
    };
};
exports.createRole = createRole;
const updateRoleInfo = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const roleKey = (ctx.params.roleKey || '').trim();
    const param = (ctx.request.body || {});
    if (!roleKey) {
        (0, http_handler_1.badRequest)('roleKey 不能为空');
    }
    if (roleKey === DEFAULT_ROLE_KEY) {
        (0, http_handler_1.badRequest)('default 角色不可修改');
    }
    const role = await (0, user_service_1.queryRole)({ role_key: roleKey });
    if (!role) {
        (0, http_handler_1.badRequest)('角色不存在');
    }
    const nextData = {};
    if (typeof param.roleName === 'string') {
        const roleName = param.roleName.trim();
        if (!roleName) {
            (0, http_handler_1.badRequest)('角色名称不能为空');
        }
        nextData.role_name = roleName;
    }
    if (param.features !== undefined) {
        const features = normalizeRoleFeatures(param.features);
        nextData.features = (0, user_service_1.stringifyRoleFeatures)(features);
    }
    if (Object.keys(nextData).length === 0) {
        (0, http_handler_1.badRequest)('未提供可更新字段');
    }
    await (0, user_service_1.updateRole)(roleKey, nextData);
    const updated = await (0, user_service_1.queryRole)({ role_key: roleKey });
    if (!updated) {
        (0, http_handler_1.badRequest)('角色不存在');
        return;
    }
    return {
        roleKey: updated.dataValues.role_key,
        roleName: updated.dataValues.role_name,
        features: (0, user_service_1.parseRoleFeatures)(updated.dataValues.features),
    };
};
exports.updateRoleInfo = updateRoleInfo;
const removeRole = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const roleKey = (ctx.params.roleKey || '').trim();
    if (!roleKey) {
        (0, http_handler_1.badRequest)('roleKey 不能为空');
    }
    if (roleKey === DEFAULT_ROLE_KEY) {
        (0, http_handler_1.badRequest)('default 角色不可删除');
    }
    const role = await (0, user_service_1.queryRole)({ role_key: roleKey });
    if (!role) {
        (0, http_handler_1.badRequest)('角色不存在');
    }
    const userCount = await (0, user_service_1.countUsersByRoleKey)(roleKey);
    if (userCount > 0) {
        (0, http_handler_1.badRequest)('该角色仍被用户使用，无法删除');
    }
    await (0, user_service_1.deleteRole)(roleKey);
    return {
        success: true,
    };
};
exports.removeRole = removeRole;
const assignUserRole = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const param = (ctx.request.body || {});
    const { userId } = param;
    const roleKey = param.roleKey?.trim();
    if (!userId || !roleKey) {
        (0, http_handler_1.badRequest)('参数错误');
    }
    const user = await (0, user_service_1.queryUser)({ id: userId });
    if (!user) {
        (0, http_handler_1.badRequest)('用户不存在');
        return;
    }
    const role = await (0, user_service_1.queryRole)({ role_key: roleKey });
    if (!role) {
        (0, http_handler_1.badRequest)('角色不存在');
        return;
    }
    await (0, user_service_1.updateUser)(userId, {
        role_key: roleKey,
    });
    const updated = await (0, user_service_1.queryUser)({ id: userId });
    if (!updated) {
        (0, http_handler_1.badRequest)('用户不存在');
        return;
    }
    return toUserResponse(updated.dataValues);
};
exports.assignUserRole = assignUserRole;
const getUserDetail = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可访问');
    }
    const id = (ctx.params.id || '').trim();
    if (!id) {
        (0, http_handler_1.badRequest)('用户ID不能为空');
    }
    const user = await (0, user_service_1.queryUser)({ id });
    if (!user) {
        (0, http_handler_1.badRequest)('用户不存在');
        return;
    }
    return toUserResponse(user.dataValues);
};
exports.getUserDetail = getUserDetail;
const adminCreateUser = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const param = (ctx.request.body || {});
    const email = param.email?.trim();
    const password = param.password?.trim();
    const nickname = typeof param.nickname === 'string' ? param.nickname.trim() : undefined;
    const avatar = typeof param.avatar === 'string' ? param.avatar.trim() : undefined;
    const role = (param.role || types_1.UserRole.USER);
    const roleKey = (param.roleKey || DEFAULT_ROLE_KEY).trim();
    if (!email || !password) {
        (0, http_handler_1.badRequest)('邮箱或密码不能为空');
    }
    if (!EMAIL_REGEXP.test(email)) {
        (0, http_handler_1.badRequest)('邮箱格式错误');
    }
    if (nickname && nickname.length > 32) {
        (0, http_handler_1.badRequest)('昵称长度不能超过 32');
    }
    if (avatar && !AVATAR_URL_REGEXP.test(avatar)) {
        (0, http_handler_1.badRequest)('头像地址必须是 http/https 链接或 /file/ 开头的上传地址');
    }
    if (!Object.values(types_1.UserRole).includes(role)) {
        (0, http_handler_1.badRequest)('系统角色非法');
    }
    await ensureDefaultRole();
    const roleObj = await (0, user_service_1.queryRole)({ role_key: roleKey });
    if (!roleObj) {
        (0, http_handler_1.badRequest)('角色组不存在');
    }
    const exists = await (0, user_service_1.queryUser)({ email });
    if (exists) {
        (0, http_handler_1.badRequest)('用户已存在');
    }
    const user = await (0, user_service_1.addUser)({
        email,
        email_verified: false,
        password,
        nickname,
        avatar,
        role,
        role_key: roleKey,
    });
    return toUserResponse(user.dataValues);
};
exports.adminCreateUser = adminCreateUser;
const adminUpdateUser = async (ctx) => {
    if (ctx.state.userInfo?.role !== types_1.UserRole.ADMIN) {
        (0, http_handler_1.unauthorized)('仅管理员可操作');
    }
    const id = (ctx.params.id || '').trim();
    if (!id) {
        (0, http_handler_1.badRequest)('用户ID不能为空');
    }
    const target = await (0, user_service_1.queryUser)({ id });
    if (!target) {
        (0, http_handler_1.badRequest)('用户不存在');
        return;
    }
    const param = (ctx.request.body || {});
    const nextData = {};
    if (typeof param.nickname === 'string') {
        const nickname = param.nickname.trim();
        if (nickname.length > 32) {
            (0, http_handler_1.badRequest)('昵称长度不能超过 32');
        }
        nextData.nickname = nickname;
    }
    if (typeof param.avatar === 'string') {
        const avatar = param.avatar.trim();
        if (avatar && !AVATAR_URL_REGEXP.test(avatar)) {
            (0, http_handler_1.badRequest)('头像地址必须是 http/https 链接或 /file/ 开头的上传地址');
        }
        nextData.avatar = avatar;
    }
    if (param.role !== undefined) {
        if (!Object.values(types_1.UserRole).includes(param.role)) {
            (0, http_handler_1.badRequest)('系统角色非法');
        }
        if (String(ctx.state.userInfo?.id) === id && param.role !== types_1.UserRole.ADMIN) {
            (0, http_handler_1.badRequest)('不能取消自己的管理员权限');
        }
        nextData.role = param.role;
    }
    if (typeof param.roleKey === 'string') {
        const roleKey = param.roleKey.trim();
        if (!roleKey) {
            (0, http_handler_1.badRequest)('角色组不能为空');
        }
        const roleObj = await (0, user_service_1.queryRole)({ role_key: roleKey });
        if (!roleObj) {
            (0, http_handler_1.badRequest)('角色组不存在');
        }
        nextData.role_key = roleKey;
    }
    if (Object.keys(nextData).length === 0) {
        (0, http_handler_1.badRequest)('未提供可更新字段');
    }
    await (0, user_service_1.updateUser)(id, nextData);
    const updated = await (0, user_service_1.queryUser)({ id });
    if (!updated) {
        (0, http_handler_1.badRequest)('用户不存在');
        return;
    }
    return toUserResponse(updated.dataValues);
};
exports.adminUpdateUser = adminUpdateUser;
