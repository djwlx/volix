"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jwt_1 = __importDefault(require("../utils/jwt"));
const index_1 = __importDefault(require("../../config/index"));
const path_to_regexp_1 = require("path-to-regexp");
const response_1 = require("../utils/response");
const user_1 = require("../modules/user");
const types_1 = require("@volix/types");
const testArray = (array, key) => {
    return array.some(item => {
        const regexpTemp = (0, path_to_regexp_1.pathToRegexp)(item);
        return regexpTemp.test(key);
    });
};
// 权限校验中间件，鉴权通过之后，将用户信息保存在state中方便后续操作没有权限返回401
const authenticate = (option) => {
    return async (ctx, next) => {
        // 自定义token放在header中，所以从header中去取，也可以放在其他地方
        const { header, url } = ctx.request;
        const { include = [], notInclude = [] } = option || {};
        // 控制哪些路由不进行权限校验
        if (testArray(notInclude, url) && !testArray(include, url)) {
            await next();
            return;
        }
        // 权限校验
        const token = header[index_1.default.token];
        if (!token) {
            (0, response_1.resError)(ctx, {
                code: 401,
                message: '未进行权限认证',
            });
        }
        else {
            // 认证成功后可以从数据库中取出用户信息放到ctx的state中,只捕获认证错误
            try {
                const data = jwt_1.default.getData(token);
                const { id } = data;
                const userInfo = await (0, user_1.queryUser)({ id: id });
                if (!userInfo) {
                    (0, response_1.resError)(ctx, {
                        code: 401,
                        message: '用户不存在',
                    });
                    return;
                }
                if (userInfo.dataValues.id === undefined || userInfo.dataValues.id === null || !userInfo.dataValues.email) {
                    (0, response_1.resError)(ctx, {
                        code: 401,
                        message: '用户信息异常',
                    });
                    return;
                }
                ctx.state.userInfo = {
                    id: userInfo.dataValues.id,
                    email: userInfo.dataValues.email,
                    nickname: userInfo.dataValues.nickname,
                    avatar: userInfo.dataValues.avatar,
                    role: (userInfo.dataValues.role || types_1.UserRole.USER),
                    roleKey: userInfo.dataValues.role_key,
                };
                await next();
            }
            catch (e) {
                (0, response_1.resError)(ctx, {
                    code: 401,
                    message: '权限认证错误',
                });
            }
        }
    };
};
exports.default = authenticate;
