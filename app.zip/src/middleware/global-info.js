"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const user_1 = require("../modules/user");
const types_1 = require("@volix/types");
// 权限校验中间件，鉴权通过之后，将用户信息保存在state中方便后续操作没有权限返回401
const getGlobalInfo = () => {
    return async (ctx, next) => {
        const userId = ctx.state.userInfo?.id;
        if (!userId) {
            return next();
        }
        const userInfo = await (0, user_1.queryUser)({ id: userId });
        if (userInfo && userInfo.dataValues.id !== undefined && userInfo.dataValues.id !== null && userInfo.dataValues.email) {
            ctx.state.userInfo = {
                id: userInfo.dataValues.id,
                email: userInfo.dataValues.email,
                nickname: userInfo.dataValues.nickname,
                avatar: userInfo.dataValues.avatar,
                role: (userInfo.dataValues.role || types_1.UserRole.USER),
                roleKey: userInfo.dataValues.role_key,
            };
        }
        next();
    };
};
exports.default = getGlobalInfo;
