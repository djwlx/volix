"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const koa_static_1 = __importDefault(require("koa-static"));
const path_1 = require("../utils/path");
const koa_mount_1 = __importDefault(require("koa-mount"));
const fs_1 = __importDefault(require("fs"));
// 一些特殊文件的路径，除此之外都走前端
const staticMap = {
    // 静态资源
    '/assets': (0, koa_mount_1.default)('/assets', (0, koa_static_1.default)(`${path_1.PATH.public}/assets`)),
    '/logo.svg': (0, koa_mount_1.default)('/', (0, koa_static_1.default)(path_1.PATH.public)),
    // 直链
    '/file': (0, koa_mount_1.default)('/file', (0, koa_static_1.default)(path_1.PATH.upload)),
};
// 静态文件中间件，负责返回前端需要的内容
const staticMiddleware = () => {
    return async (ctx, next) => {
        const { method, // 请求方法
        url, // 请求链接
         } = ctx?.request;
        if (method === 'GET' && !url.startsWith('/api')) {
            let staticWare;
            Object.keys(staticMap).forEach(urlItem => {
                if (url.startsWith(urlItem)) {
                    staticWare = staticMap[urlItem];
                }
            });
            if (staticWare) {
                await staticWare(ctx, next);
            }
            else {
                //走前端路径
                ctx.type = 'html';
                ctx.body = fs_1.default.createReadStream(`${path_1.PATH.public}/index.html`);
            }
        }
        else {
            return await next();
        }
    };
};
exports.default = staticMiddleware;
