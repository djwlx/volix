"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.createQbittorrentSdk = createQbittorrentSdk;
const request_1 = __importStar(require("../../utils/request"));
function createQbittorrentSdk(options) {
    const { apiHost, username, password } = options;
    const normalizedHost = apiHost.replace(/\/+$/, '');
    const hostOrigin = new URL(normalizedHost).origin;
    let cookie = null;
    const toFormData = (data) => {
        return new URLSearchParams(Object.entries(data).reduce((acc, [key, value]) => {
            acc[key] = String(value);
            return acc;
        }, {}));
    };
    const normalizeHashes = (hashes = 'all') => {
        if (hashes === 'all') {
            return 'all';
        }
        if (typeof hashes === 'string') {
            const value = hashes.trim();
            if (!value) {
                throw new Error('hashes 不能为空');
            }
            return value;
        }
        const values = hashes.map(item => item.trim()).filter(Boolean);
        if (values.length === 0) {
            throw new Error('hashes 不能为空');
        }
        return values.join('|');
    };
    const getSidFromHeaders = (setCookieHeader) => {
        if (Array.isArray(setCookieHeader)) {
            for (const item of setCookieHeader) {
                const sid = (0, request_1.getCookieValue)(item, 'SID');
                if (sid) {
                    return sid;
                }
            }
            return null;
        }
        return setCookieHeader ? (0, request_1.getCookieValue)(setCookieHeader, 'SID') : null;
    };
    const login = async () => {
        const result = await request_1.default.post(`${normalizedHost}/api/v2/auth/login`, toFormData({
            username,
            password,
        }), {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Referer: normalizedHost,
                Origin: hostOrigin,
            },
        });
        cookie = getSidFromHeaders(result.headers['set-cookie']);
        if (!cookie) {
            throw new Error('qBittorrent 登录失败，未获取到 SID');
        }
    };
    const getErrorStatus = (error) => {
        const responseStatus = error?.response?.status;
        return typeof responseStatus === 'number' ? responseStatus : undefined;
    };
    const qbitRequest = async (params, retryOnAuthError = true) => {
        if (!cookie) {
            await login();
        }
        try {
            return await (0, request_1.default)({
                ...params,
                baseURL: normalizedHost,
                headers: {
                    Cookie: `SID=${cookie}`,
                    Referer: normalizedHost,
                    Origin: hostOrigin,
                    ...(params.data ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}),
                    ...params.headers,
                },
            });
        }
        catch (error) {
            const status = getErrorStatus(error);
            if (retryOnAuthError && (status === 401 || status === 403)) {
                await login();
                return qbitRequest(params, false);
            }
            throw error;
        }
    };
    const torrentAction = async (action, payload) => {
        await qbitRequest({
            url: `/api/v2/torrents/${action}`,
            method: 'POST',
            data: toFormData(payload),
        });
        return 'ok';
    };
    const getTorrentList = async () => {
        const result = await qbitRequest({
            url: '/api/v2/torrents/info',
            method: 'GET',
        });
        return result.data;
    };
    const addTorrents = async (params) => {
        if (!Array.isArray(params.urls) || params.urls.length === 0) {
            throw new Error('urls 不能为空');
        }
        const urls = params.urls.map(item => item.trim()).filter(Boolean);
        if (urls.length === 0) {
            throw new Error('urls 不能为空');
        }
        const tags = (params.tags || []).map(item => item.trim()).filter(Boolean);
        await qbitRequest({
            url: '/api/v2/torrents/add',
            method: 'POST',
            data: toFormData({
                urls: urls.join('\n'),
                ...(params.category ? { category: params.category } : {}),
                ...(tags.length > 0 ? { tags: tags.join(',') } : {}),
                ...(params.paused !== undefined ? { paused: params.paused } : {}),
                ...(params.skipChecking !== undefined ? { skip_checking: params.skipChecking } : {}),
                ...(params.savepath ? { savepath: params.savepath } : {}),
            }),
        });
        return 'ok';
    };
    const getTorrentByHash = async (hash) => {
        const targetHash = hash.trim().toLowerCase();
        if (!targetHash) {
            throw new Error('hash 不能为空');
        }
        const list = await getTorrentList();
        return list.find(item => item.hash.toLowerCase() === targetHash) || null;
    };
    const getTorrentsByTag = async (tag) => {
        const targetTag = tag.trim();
        if (!targetTag) {
            throw new Error('tag 不能为空');
        }
        const list = await getTorrentList();
        return list.filter(item => (item.tags || '').split(',').map(it => it.trim()).includes(targetTag));
    };
    const pauseTorrents = async (hashes = 'all') => {
        return torrentAction('stop', { hashes: normalizeHashes(hashes) });
    };
    const resumeTorrents = async (hashes = 'all') => {
        return torrentAction('start', { hashes: normalizeHashes(hashes) });
    };
    const deleteTorrents = async (hashes, options = {}) => {
        return torrentAction('delete', {
            hashes: normalizeHashes(hashes),
            deleteFiles: options.deleteFiles ? 'true' : 'false',
        });
    };
    const recheckTorrents = async (hashes) => {
        return torrentAction('recheck', { hashes: normalizeHashes(hashes) });
    };
    const reannounceTorrents = async (hashes) => {
        return torrentAction('reannounce', { hashes: normalizeHashes(hashes) });
    };
    const pauseAll = async () => {
        return pauseTorrents('all');
    };
    const startAll = async () => {
        return resumeTorrents('all');
    };
    return {
        login,
        qbitRequest,
        addTorrents,
        getTorrentList,
        getTorrentByHash,
        getTorrentsByTag,
        pauseTorrents,
        resumeTorrents,
        deleteTorrents,
        recheckTorrents,
        reannounceTorrents,
        pauseAll,
        startAll,
    };
}
