"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.hashOpenlistPassword = void 0;
exports.createOpenlistSdk = createOpenlistSdk;
const crypto_1 = require("crypto");
const request_1 = __importDefault(require("../../utils/request"));
const OPENLIST_HASH_SUFFIX = '-https://github.com/alist-org/alist';
const toSnakePageReq = (params) => {
    return {
        page: params?.page ?? 1,
        per_page: params?.perPage ?? 20,
    };
};
const hashOpenlistPassword = (plainPassword) => {
    return (0, crypto_1.createHash)('sha256').update(`${plainPassword}${OPENLIST_HASH_SUFFIX}`).digest('hex');
};
exports.hashOpenlistPassword = hashOpenlistPassword;
function createOpenlistSdk(options) {
    const normalizedHost = options.apiHost.replace(/\/+$/, '');
    let token = options.token || '';
    const getToken = () => token;
    const setToken = (nextToken) => {
        token = (nextToken || '').trim();
    };
    const clearToken = () => {
        token = '';
    };
    const requestOpenlist = async (config, needAuth = true) => {
        if (needAuth && !token) {
            throw new Error('OpenList token 不存在，请先登录');
        }
        const result = await (0, request_1.default)({
            ...config,
            baseURL: normalizedHost,
            headers: {
                'Content-Type': 'application/json',
                ...(needAuth ? { Authorization: token } : {}),
                ...(config.headers || {}),
            },
        });
        const data = result.data;
        if (!data || data.code !== 200) {
            throw new Error(data?.message || 'OpenList 请求失败');
        }
        return data.data;
    };
    const login = async (params) => {
        const data = await requestOpenlist({
            url: '/api/auth/login',
            method: 'POST',
            data: {
                username: params.username,
                password: params.password,
                ...(params.otpCode ? { otp_code: params.otpCode } : {}),
            },
        }, false);
        setToken(data.token);
        return data;
    };
    const loginWithHashedPassword = async (username, plainPassword) => {
        const passwordHash = (0, exports.hashOpenlistPassword)(plainPassword);
        const data = await requestOpenlist({
            url: '/api/auth/login/hash',
            method: 'POST',
            data: {
                username,
                password: passwordHash,
            },
        }, false);
        setToken(data.token);
        return data;
    };
    const logout = async () => {
        await requestOpenlist({
            url: '/api/auth/logout',
            method: 'POST',
        });
        clearToken();
        return true;
    };
    const getMe = async () => {
        return requestOpenlist({
            url: '/api/me',
            method: 'GET',
        });
    };
    const listFs = async (params) => {
        return requestOpenlist({
            url: '/api/fs/list',
            method: 'POST',
            data: {
                path: params.path,
                password: params.password || '',
                page: params.page ?? 1,
                per_page: params.perPage ?? 0,
                refresh: params.refresh ?? false,
            },
        });
    };
    const getFs = async (params) => {
        return requestOpenlist({
            url: '/api/fs/get',
            method: 'POST',
            data: {
                path: params.path,
                password: params.password || '',
            },
        });
    };
    const mkdir = async (params) => {
        return requestOpenlist({
            url: '/api/fs/mkdir',
            method: 'POST',
            data: {
                path: params.path,
            },
        });
    };
    const rename = async (params) => {
        return requestOpenlist({
            url: '/api/fs/rename',
            method: 'POST',
            data: {
                path: params.path,
                name: params.name,
            },
        });
    };
    const move = async (params) => {
        return requestOpenlist({
            url: '/api/fs/move',
            method: 'POST',
            data: {
                src_dir: params.srcDir,
                dst_dir: params.dstDir,
                names: params.names,
            },
        });
    };
    const copy = async (params) => {
        return requestOpenlist({
            url: '/api/fs/copy',
            method: 'POST',
            data: {
                src_dir: params.srcDir,
                dst_dir: params.dstDir,
                names: params.names,
            },
        });
    };
    const remove = async (params) => {
        return requestOpenlist({
            url: '/api/fs/remove',
            method: 'POST',
            data: {
                dir: params.dir,
                names: params.names,
            },
        });
    };
    const listStorages = async (pageReq) => {
        return requestOpenlist({
            url: '/api/admin/storage/list',
            method: 'POST',
            data: toSnakePageReq(pageReq),
        });
    };
    const listShares = async (pageReq) => {
        return requestOpenlist({
            url: '/api/share/list',
            method: 'POST',
            data: toSnakePageReq(pageReq),
        });
    };
    const getPublicSettings = async () => {
        return requestOpenlist({
            url: '/api/public/settings',
            method: 'GET',
        }, false);
    };
    return {
        getToken,
        setToken,
        clearToken,
        requestOpenlist,
        login,
        loginWithHashedPassword,
        logout,
        getMe,
        listFs,
        getFs,
        mkdir,
        rename,
        move,
        copy,
        remove,
        listStorages,
        listShares,
        getPublicSettings,
    };
}
