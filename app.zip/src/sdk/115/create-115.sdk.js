"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.create115Sdk = create115Sdk;
const form_data_1 = __importDefault(require("form-data"));
const qrcode_1 = __importDefault(require("qrcode"));
const request_1 = __importDefault(require("../../utils/request"));
const secret_1 = require("./secret");
const api = {
    qrCodeToken: 'https://qrcodeapi.115.com/api/1.0/web/1.0/token',
    qrCodeStatus: 'https://qrcodeapi.115.com/get/status/',
    qrCodeLoginWithApp: (app = 'ios') => `https://passportapi.115.com/app/1.0/${app}/1.0/login/qrcode`,
    loginCheck: 'https://passportapi.115.com/app/1.0/web/1.0/check/sso',
    fileList: 'https://webapi.115.com/files',
    downloadUrl: 'https://proapi.115.com/app/chrome/downurl',
    userInfo: 'https://my.115.com/?ct=ajax&ac=nav',
};
function create115Sdk(options) {
    let cookie = options?.cookie;
    const getCookie = () => cookie;
    const setCookie = (nextCookie) => {
        cookie = nextCookie;
    };
    const clearCookie = () => {
        cookie = undefined;
    };
    const getToken = async () => {
        const result = await request_1.default.get(api.qrCodeToken);
        return result.data?.data;
    };
    const getQrCode = async () => {
        const token = await getToken();
        const { qrcode } = token;
        const qrCodeImg = await qrcode_1.default.toDataURL(qrcode);
        return {
            qrCode: qrcode,
            qrCodeValue: token,
            qrCodeImg,
        };
    };
    const getQrStatus = async (params) => {
        const result = await request_1.default.get(api.qrCodeStatus, {
            params,
        });
        return result.data;
    };
    const checkLogin = async () => {
        const result = await request_1.default.get(api.loginCheck, {
            headers: {
                Cookie: getCookie(),
            },
        });
        return result.data;
    };
    const getUserInfo = async () => {
        if (!cookie) {
            return null;
        }
        const result = await request_1.default.get(api.userInfo, {
            params: {
                _: Math.floor(Date.now() / 1000),
            },
            headers: {
                Cookie: getCookie(),
            },
        });
        return result.data?.data;
    };
    const loginWithApp = async (uid, paramApp) => {
        const app = paramApp || 'ios';
        const url = api.qrCodeLoginWithApp(app);
        const form = new form_data_1.default();
        form.append('account', uid);
        form.append('app', app);
        const result = await request_1.default.post(url, form);
        const resCookie = result?.data?.data?.cookie;
        const cookieString = Object.entries(resCookie)
            .map(([key, value]) => `${key}=${value}`)
            .join(';');
        setCookie(cookieString);
        return {
            data: result.data,
            cookie: cookieString,
        };
    };
    const getFileList = async (offset, pageSize, cid) => {
        const params = {
            aid: '1',
            cid: cid || '0',
            o: 'user_ptime',
            asc: '1',
            offset: offset || 0,
            show_dir: '1',
            limit: pageSize || 10,
            snap: '0',
            natsort: '0',
            record_open_time: '1',
            format: 'json',
            fc_mix: '0',
        };
        const result = await request_1.default.get(api.fileList, {
            params,
            headers: {
                Cookie: getCookie(),
            },
        });
        return result.data;
    };
    const getFile = async (pc, ua) => {
        const now = Date.now();
        const timestamp = Math.floor(now / 1000);
        const { data, key } = secret_1.secret.encode(JSON.stringify({ pickcode: pc }), timestamp);
        const formData = new form_data_1.default();
        formData.append('data', data);
        const result = await request_1.default.post(api.downloadUrl, formData, {
            headers: {
                'User-Agent': ua,
                'Content-Type': 'application/x-www-form-urlencoded',
                Cookie: getCookie(),
            },
        });
        const str = secret_1.secret.decode(result.data?.data, key);
        return JSON.parse(str);
    };
    return {
        getCookie,
        setCookie,
        clearCookie,
        getQrCode,
        getQrStatus,
        checkLogin,
        getUserInfo,
        loginWithApp,
        getFileList,
        getFile,
    };
}
