"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const router_1 = __importDefault(require("@koa/router"));
const user_route_1 = __importDefault(require("../modules/user/user.route"));
const util_route_1 = __importDefault(require("../modules/util/util.route"));
const file_route_1 = __importDefault(require("../modules/file/file.route"));
const _115_route_1 = __importDefault(require("../modules/115/115.route"));
const router = new router_1.default({
    prefix: '/api',
});
router.use(_115_route_1.default.routes());
router.use(util_route_1.default.routes());
router.use(file_route_1.default.routes());
router.use(user_route_1.default.routes());
exports.default = router;
