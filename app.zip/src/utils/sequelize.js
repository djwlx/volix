"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const sequelize_1 = require("sequelize");
const logger_1 = require("./logger");
const path_1 = require("./path");
// 创建是同步的，执行数据库操作是异步的
const sequelize = new sequelize_1.Sequelize({
    dialect: 'sqlite',
    storage: path_1.PATH.database,
    logging: sql => logger_1.baseLog.info(sql),
    define: {
        freezeTableName: true,
        createdAt: 'created_at',
        updatedAt: 'updated_at',
    },
});
try {
    sequelize.authenticate().then(() => { });
}
catch (error) {
    logger_1.log.error('连接数据库错误', error);
}
exports.default = sequelize;
