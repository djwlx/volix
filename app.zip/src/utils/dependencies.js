"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = require("./path");
const fs_1 = __importDefault(require("fs"));
const logger_1 = require("./logger");
const initApp = async () => {
    // 创建必要的目录
    const pathList = [
        { filePath: path_1.PATH.log, type: 'dir' },
        { filePath: path_1.PATH.upload, type: 'dir' },
    ];
    for (const { filePath, type } of pathList) {
        if (type === 'dir' && !fs_1.default.existsSync(filePath)) {
            logger_1.log.info(`生成文件夹 ${filePath}`);
            fs_1.default.mkdirSync(filePath, { recursive: true });
        }
    }
};
exports.default = initApp;
