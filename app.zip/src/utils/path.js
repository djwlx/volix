"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PATH = void 0;
const path_1 = __importDefault(require("path"));
const ROOT = process.cwd();
const DATA = '/data';
exports.PATH = {
    get root() {
        return ROOT;
    },
    get data() {
        return path_1.default.join(ROOT, DATA);
    },
    get log() {
        return path_1.default.join(ROOT, DATA, 'log');
    },
    get database() {
        return path_1.default.join(ROOT, DATA, 'index.db');
    },
    get upload() {
        return path_1.default.join(ROOT, DATA, 'upload');
    },
    get public() {
        return path_1.default.join(ROOT, 'public');
    },
};
