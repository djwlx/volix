"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lightLocks = void 0;
exports.lightLocks = {
    is115PictureCaching: false,
};
