"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENV = void 0;
const { NODE_ENV } = process.env;
exports.ENV = {
    isProd: NODE_ENV === 'production',
};
