"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const key = 'DJWL';
class JWT {
    static setToken(data) {
        return jsonwebtoken_1.default.sign(data, key, {
            expiresIn: '48h',
        });
    }
    static getData(token) {
        const data = jsonwebtoken_1.default.verify(token, key);
        if (typeof data === 'string' || !data || !('id' in data)) {
            throw new Error('无效的token');
        }
        return data;
    }
}
exports.default = JWT;
