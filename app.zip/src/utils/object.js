"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.makeStaticClass = void 0;
// 将普通类转化为静态类
const makeStaticClass = (targetClass) => {
    const staticClass = {};
    Object.getOwnPropertyNames(targetClass.prototype).forEach(method => {
        if (method !== 'constructor') {
            staticClass[method] = targetClass.prototype[method];
        }
    });
    return staticClass;
};
exports.makeStaticClass = makeStaticClass;
