"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUnixTime = exports.waitTime = exports.calculateTimeDifference = exports.getNowTimeStrinng = void 0;
const getNowTimeStrinng = (paramData) => {
    const date = paramData ?? new Date();
    const formattedDate = date.getFullYear() +
        '-' +
        ('0' + (date.getMonth() + 1)).slice(-2) +
        '-' +
        ('0' + date.getDate()).slice(-2) +
        ' ' +
        ('0' + date.getHours()).slice(-2) +
        ':' +
        ('0' + date.getMinutes()).slice(-2) +
        ':' +
        ('0' + date.getSeconds()).slice(-2);
    return formattedDate;
};
exports.getNowTimeStrinng = getNowTimeStrinng;
const calculateTimeDifference = (start, end) => {
    const difference = end - start; // 差值（以毫秒为单位）
    // 计算时、分、秒和毫秒
    const hours = Math.floor(difference / (1000 * 60 * 60));
    const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((difference % (1000 * 60)) / 1000);
    const milliseconds = difference % 1000;
    // 条件拼接非0的部分
    const parts = [];
    if (hours)
        parts.push(`${hours}h`);
    if (minutes)
        parts.push(`${minutes}m`);
    if (seconds)
        parts.push(`${seconds}s`);
    if (milliseconds)
        parts.push(`${milliseconds}ms`);
    return parts.join(' ');
};
exports.calculateTimeDifference = calculateTimeDifference;
const waitTime = (time) => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve('');
        }, time);
    });
};
exports.waitTime = waitTime;
const getUnixTime = (date) => {
    return Math.floor(date?.getTime() ?? Date.now() / 1000);
};
exports.getUnixTime = getUnixTime;
