"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.taskLog = exports.baseLog = exports.log = void 0;
const path_1 = __importDefault(require("path"));
const log4js_1 = __importDefault(require("log4js"));
const path_2 = require("./path");
const { NODE_ENV } = process.env;
const isProd = NODE_ENV === 'production';
log4js_1.default.configure({
    appenders: {
        console: {
            type: 'console',
        },
        normal: {
            type: 'dateFile',
            alwaysIncludePattern: true,
            maxLogSize: 10485760,
            pattern: 'yyyy-MM-dd.log',
            filename: path_1.default.join(`${path_2.PATH.log}/normal`, 'normal'), //生成文件名
            numBackups: 5,
        },
        database: {
            type: 'dateFile',
            alwaysIncludePattern: true,
            maxLogSize: 10485760,
            pattern: 'yyyy-MM-dd.log',
            filename: path_1.default.join(`${path_2.PATH.log}/databse`, 'database'), //生成文件名
            numBackups: 5,
        },
        task: {
            type: 'dateFile',
            alwaysIncludePattern: true,
            maxLogSize: 10485760,
            pattern: 'yyyy-MM-dd.log',
            filename: path_1.default.join(`${path_2.PATH.log}/task`, 'task'), //生成文件名
            numBackups: 5,
        },
    },
    categories: {
        prodNormal: {
            appenders: ['normal', 'console'],
            level: 'all',
        },
        devNormal: {
            appenders: ['console'],
            level: 'all',
        },
        dataBase: {
            appenders: ['database'],
            level: 'all',
        },
        taskInfo: {
            appenders: ['task'],
            level: 'all',
        },
        default: {
            appenders: ['console'],
            level: 'all',
        },
    },
});
// 普通日志
const log = log4js_1.default.getLogger(isProd ? 'prodNormal' : 'devNormal');
exports.log = log;
// 数据库日志
const baseLog = log4js_1.default.getLogger('dataBase');
exports.baseLog = baseLog;
// 任务日志
const taskLog = log4js_1.default.getLogger('taskInfo');
exports.taskLog = taskLog;
