"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.resError = exports.resSuccess = void 0;
const resSuccess = (ctx, params) => {
    const { data, code, message } = params || {};
    ctx.body = {
        code: code ?? 0,
        message: message || 'success',
        data: data ?? {},
    };
};
exports.resSuccess = resSuccess;
const resError = (ctx, params) => {
    const { data, code, message } = params || {};
    ctx.status = code;
    ctx.body = {
        code,
        message,
        data: data ?? {},
    };
};
exports.resError = resError;
