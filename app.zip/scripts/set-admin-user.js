"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = require("@volix/types");
const user_model_1 = require("../src/modules/user/model/user.model");
async function setAdminUserById(userId) {
    try {
        const user = await user_model_1.UserModel.findByPk(userId);
        if (!user) {
            console.error(`未找到 id=${userId} 的用户`);
            process.exitCode = 1;
            return;
        }
        if (user.dataValues.role === types_1.UserRole.ADMIN) {
            console.log(`id=${userId} 的用户已经是管理员`);
            process.exitCode = 0;
            return;
        }
        await user_model_1.UserModel.update({ role: types_1.UserRole.ADMIN }, {
            where: {
                id: userId,
            },
        });
        console.log(`已将 id=${userId} 的用户设置为管理员`);
        process.exitCode = 0;
    }
    catch (error) {
        console.error('更新用户角色失败:', error);
        process.exitCode = 1;
    }
}
setAdminUserById(1);
