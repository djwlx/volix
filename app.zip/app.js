"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const koa_1 = __importDefault(require("koa"));
const routes_1 = __importDefault(require("./src/routes"));
const cors_1 = __importDefault(require("@koa/cors"));
const koa_body_1 = require("koa-body");
const log_1 = __importDefault(require("./src/middleware/log"));
const config_1 = __importDefault(require("./config"));
const global_info_1 = __importDefault(require("./src/middleware/global-info"));
const static_1 = __importDefault(require("./src/middleware/static"));
const dependencies_1 = __importDefault(require("./src/utils/dependencies"));
const logger_1 = require("./src/utils/logger");
const utils_1 = require("@volix/utils");
console.log((0, utils_1.formatTime)());
async function startApp() {
    // 启动前操作
    await (0, dependencies_1.default)();
    const app = new koa_1.default();
    // 跨域
    app.use((0, cors_1.default)());
    // 解析requestBody
    app.use((0, koa_body_1.koaBody)({ multipart: true }));
    // 记录日志
    app.use((0, log_1.default)());
    //静态文件
    app.use((0, static_1.default)());
    // 全局信息
    app.use((0, global_info_1.default)());
    // 路由
    app.use(routes_1.default.routes());
    app.listen(config_1.default.port, () => {
        logger_1.log.info('应用启动在端口：', config_1.default.port);
    });
}
startApp();
